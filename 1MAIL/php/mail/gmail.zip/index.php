<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Send Email</title>
  </head>
  <body>
    <form class="" action="send.php" method="post" style="display:block; justify-content: center; align-items:center;">
      Email <input type="email" name="email" value=""> <br><br>
      Subject <input type="text" name="subject" value=""> <br><br>
      Message <input type="text" name="message" value=""> <br><br>
      Name <input type="text" name="name" value=""> <br><br>
      Phone <input type="text" name="phone" value=""> <br><br>
      <button type="submit" name="send">Send</button>
    </form>
  </body>
</html>
